 <?php
 error_reporting(E_ERROR | E_PARSE);
    session_start();
    ?>
<!DOCTYPE html>
   
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MTIBA: HARAMBEES</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
     <link href="css/bootstrap-imageupload.css" rel="stylesheet">
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="index.php" style="color: white;">Harambee(s)</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="index.php">Profile</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="admin.php">My Harambee(s)</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#portfolio">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
       
        
        <header style="text-align: left; color: black;">
        <br/><br/><br/>
               <div class="container">
        <div class="span12">
    		<div class="" id="loginModal">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 style="color: white;">MTIBA: Harambee Platform</h3>
                 <?php
        echo "<p style='color: white'>";
        echo $_SESSION["name"]."<br/>";
        echo $_SESSION["location"]."<br/>";
        echo $_SESSION["id"]."<br/>";
	$x=$_SESSION["phone"];
        echo $_SESSION["phone"]."<br/>";
        echo "</p>";
        ?>
              </div>
              <div class="modal-body">
                <div class="well">
                  <ul class="nav nav-tabs">
                    <li class="active"><a href="#login" data-toggle="tab">New Harambee</a></li>
                    <li><a href="#create" data-toggle="tab">My Harambee(s)</a></li>
                  </ul>
                  <div id="myTabContent" class="tab-content">
                    <div class="tab-pane active in" id="login">
                      <form class="form-horizontal" action='submit-harambee.php' method="POST" enctype="multipart/form-data">
                        <fieldset>
                          <div id="legend">
                            <legend class="">New Harambee</legend>
                          </div>    
                          <div class="control-group">
                            <!-- Username -->
                            <label class="control-label"  for="username">PHONE NUMBER</label>
                            <div class="controls">
                              <input type="text" id="username" name="phone" placeholder="" class="input-xlarge">
                            </div>
                          </div>
     
                          <div class="control-group">
                            <!-- Password-->
                            <label class="control-label" for="password1">BRIEF DESCRIPTION</label>
                            <div class="controls">
                              <textarea name="desc_" class="form-control" rows="5" id="comment"></textarea>
                            </div>
                          </div>
                          
                          <div class="control-group">
                            <!-- Username -->
                            <label class="control-label"  for="username">AMOUNT</label>
                            <div class="controls">
                              <input type="text" id="username" name="amt" placeholder="" class="input-xlarge">
                            </div>
                          </div>
                          <hr/>
                       <!--img upload-->
                       <div class="control-group">
                       <div class="imageupload panel panel-default">
    <div class="panel-h<!-- bootstrap-imageupload. -->
            <div class="imageupload panel panel-default">
                <div class="panel-heading clearfix">
                    <h3 class="panel-title pull-left">Upload Image</h3>
                    <div class="btn-group pull-right">
                        <button type="button" class="btn btn-default active">File</button>
                        <button type="button" class="btn btn-default">URL</button>
                    </div>
                </div>
                <div class="file-tab panel-body">
                    <label class="btn btn-default btn-file">
                        <span><u>Browse</u></span>
                        <!-- The file is stored here. -->
                        <input type="file" name="fileToUpload" id="fileToUpload">
                    </label>
                    <button type="button" class="btn btn-default"><u>Remove</u></button>
                </div>
                <div class="url-tab panel-body">
                    <div class="input-group">
                        <input type="text" class="form-control hasclear" placeholder="Image URL">
                        <div class="input-group-btn">
                            <button type="button" class="btn btn-default">Submit</button>
                        </div>
                    </div>
                    <button type="button" class="btn btn-default">Remove</button>
                    <!-- The URL is stored here. -->
                    <input type="hidden" name="image-url">
                </div>
            </div>
                       </div>
                       <!--img upload-->
                       
                       
        
                          <div class="control-group">
                            <!-- Button -->
                            <div class="controls">
                              <button class="btn btn-success" type="submit">Enter</button> <button class="btn btn-success" type="reset">Clear</button>
                            </div>
                          </div>
                        </fieldset>
                      </form>
                      
                       
                    </div>
                    <style>
                        table,tr,td{
                                border-width: thin;
                                padding: 20px;
                                
                        }
                    </style>
                    <div class="tab-pane fade" id="create">
                        <div id="legend">
                            <legend class="">My Harambee(s)</legend>
                          </div> 
                      <?php
		      
			$servername = "localhost";
            $username = "swiftexr";
            $pass = "71113004";
            $dbname = "swiftexr_mtiba";
			
			// Create connection
			$conn = new mysqli($servername, $username, $pass, $dbname);
			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			//echo $x;
			$sql = "SELECT * FROM harambee WHERE phone='".$x."'";
			$result = $conn->query($sql);
			$c=0;
			if ($result->num_rows > 0) {
			    // output data of each row
			    while($row = $result->fetch_assoc()) {
				$pic1=$row["pic"];
				$date1=$row["date"];
				echo ($c+1)."-><a href=contributions.php?id=".$pic1."><button class='btn btn-success'>".$date1."</button></a>";
				echo  "<a href=https://www.facebook.com/sharer/sharer.php?u=localhost/mtiba/contributions.php?id=".$pic1."><button class='btn btn-success'>SHARE</button></a>";
				echo "<hr/>";
				$c++;
			    }
			    //echo 1;
			} else {
			    echo "0 results";
			}
							
			?>
		     
				    </div>
				</div>
			      </div>
			    </div>
			</div>
			</div>
		</div>
 </header>     
  
              <script>
                            $(document).ready( function() {
    	$(document).on('change', '.btn-file :file', function() {
		var input = $(this),
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		input.trigger('fileselect', [label]);
		});

		$('.btn-file :file').on('fileselect', function(event, label) {
		    
		    var input = $(this).parents('.input-group').find(':text'),
		        log = label;
		    
		    if( input.length ) {
		        input.val(log);
		    } else {
		        if( log ) alert(log);
		    }
	    
		});
		function readURL(input) {
		    if (input.files && input.files[0]) {
		        var reader = new FileReader();
		        
		        reader.onload = function (e) {
		            $('#img-upload').attr('src', e.target.result);
		        }
		        
		        reader.readAsDataURL(input.files[0]);
		    }
		}

		$("#imgInp").change(function(){
		    readURL(this);
		}); 	
	});
                        </script>

  

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
    
    <!--img upload-->
     <script src="js/bootstrap-imageupload.js"></script>

        <script>
            var $imageupload = $('.imageupload');
            $imageupload.imageupload();

            $('#imageupload-disable').on('click', function() {
                $imageupload.imageupload('disable');
                $(this).blur();
            })

            $('#imageupload-enable').on('click', function() {
                $imageupload.imageupload('enable');
                $(this).blur();
            })

            $('#imageupload-reset').on('click', function() {
                $imageupload.imageupload('reset');
                $(this).blur();
            });
        </script>
        <!--img upload-->

</body>

</html>
