 <?php
 error_reporting(E_ERROR | E_PARSE);
 
 session_start();
 date_default_timezone_set('Africa/Nairobi')
 ?>
    <html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mkiba: Harambee(s)</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top" style="color: white;">M-KIBA: Contribution</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="index.php">Home</a>
                    </li>
                  <li>
                        <a class="page-scroll" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

  
    <header style="text-align: left; color: black;">
	<br/><br/><br/><br/>
<div class="container">
	<div class="row">
		<div class="col-md-4">
			
			<?php
   // echo $_GET['id'];
    $id=$_GET['id'];
    echo "<img class='img-rounded' height='250' width='310' src='uploads/".$id."'/>";
    $_SESSION['id']=$id;

$servername = "localhost";
$username = "swiftexr";
$pass = "71113004";
$dbname = "swiftexr_mtiba";
	
	// Create connection
	$conn = new mysqli($servername, $username, $pass, $dbname);
	// Check connection
	if ($conn->connect_error) {
	    //die("Connection failed: " . $conn->connect_error);
	}
	
					
	
	
	$sql = "SELECT * FROM harambee where pic='".$id."'";
	$result = $conn->query($sql);
	
	
	if ($result->num_rows > 0) {
	    while($row = $result->fetch_assoc()) {
		echo "<br/>";
		
		$phonex= $row["phone"];
		
		$sqls = "SELECT * FROM members where phone='".$phonex."'";
				
				$results = $conn->query($sqls);
				
				if ($results->num_rows > 0) {
				    while($rows = $results->fetch_assoc()) {
					echo "<br/>";
					
					$fname= $rows["first_name"];
					$lname= $rows["last_name"];
					
					
				
					//echo "<img class='img-rounded' height='250' width='310' src='uploads/".$id."'/>";
				    }
				} else {
				    //echo "0 results";
				}
				
				
		$desc_= $row["desc_"];
		$amt= $row["amt"];
		$date= $row["date"];
		
	
		//echo "<img class='img-rounded' height='250' width='310' src='uploads/".$id."'/>";
	    }
	} else {
	    echo "0 results";
	}
	
				

    ?>
    <?php
    $servername = "localhost";
$username = "swiftexr";
$pass = "71113004";
$dbname = "swiftexr_mtiba";
	
	// Create connection
	$conn = new mysqli($servername, $username, $pass, $dbname);
	// Check connection
	if ($conn->connect_error) {
	    //die("Connection failed: " . $conn->connect_error);
	}
	
					
	
	
	$sql = "SELECT sum(amount) as s_amt FROM contributions where index_='".$id."'";
	$result = $conn->query($sql);
	
	
	if ($result->num_rows > 0) {
	    while($row = $result->fetch_assoc()) {
	$samt=$row["s_amt"];
	    }
	} else {
	    echo "0 results";
	}
	
	//echo $samt;	
	
	$perc=(($samt/$amt)*100);

    ?>
 
		</div>
		<div class="col-md-8" style="color: white; background-color: black; opacity: 0.7; border-radius:15px;">
			<p>
				<?php
				
				
				echo $fname." ".$lname."<br/>";
				echo $phonex."<br/>";
				echo $desc_."<br/>";
				echo money_format('%i',$amt)."<br/>";
				echo $date."<br/>";
				echo $id."<br/>";
				?>
			</p>
			<br/>
			<form action="requestcheckout_2.php" method="POST">
		 <div class="control-group">
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="name" value="" placeholder="Enter Name (Optional)">                                        
                        </div>
			    <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="phone" value="" placeholder="Enter Your Number">                                        
                        </div>
			  
			  <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="amt" value="" placeholder="Enter Amount">                                        
                        </div>
			     
                          <div class="control-group">
                            <!-- Button -->
                            <div class="controls">
                              <button class="btn btn-success" type="submit">Contribute</button> <button class="btn btn-success">Reset</button>
                              
                            </div>
                </div>
			</form>
		</div>
	<?php//	echo $perc; ?>
	Progress:
	 <div class="progress">
  <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $perc; ?>"
  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $perc; ?>%">
    <?php echo $perc."%"; ?>
  </div>
</div> 

	</div>
    </div>
    </header>

</body>

</html>