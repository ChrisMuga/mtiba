<html>
    <head><title>Vigilant Citizen</title></head>
<body>
<?php
$id = $_POST["id"];
$fname = $_POST["fname"];
$lname = $_POST["lname"];
$phone = $_POST["phone"];
$email = $_POST["email"];
$password = $_POST["password"];
echo $fid."<br/>";
echo $fname." ";
echo $lname."<br/>";
echo $phone."<br/>";
echo $location."<br/>";
echo $password."<br/>";

$servername = "localhost";
$username = "root";
$pass = "root";
$dbname = "mtiba";

// Create connection
$conn = new mysqli($servername, $username, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    //die("Connection failed: " . $conn->connect_error);
}

				
$sql = "INSERT INTO members VALUES ('".$id."','".$fname."','".$lname."','".$phone."','".$email."','".$password."')";

if ($conn->query($sql) === TRUE) {
//echo "New record created successfully";

echo "<script type='text/javascript'>swal('Success', 'Supplier Registration Successful', 'success');</script>";
header("location: index.php");
} else {
//echo "Error: " . $sql . "<br>" . $conn->error;
echo "<script type='text/javascript'>swal('Error!', 'Supplier Registration Failed', 'error');</script>";
header("location: index.php");

          
}

?>
</body>
</html>