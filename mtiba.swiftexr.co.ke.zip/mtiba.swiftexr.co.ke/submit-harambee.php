    <html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mkiba: Harambee(s)</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top" style="color: white;">MWANANCHI PROFILE</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="index.php">Mwananchi</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="admin.php">Officer</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#portfolio">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

  
    <header style="text-align: left; color: black;">
        <br/><br/><br/>
        <?php
session_start();
$phone = $_POST["phone"];
$desc_ = $_POST["desc_"];
$amt = $_POST["amt"];
$pic = $_POST["fileToUpload"];
$day=date("d");
$month=date("m");
$year=date("Y");
$date=date("Y-m-d h:i:sa");
$date1=date("Ymdhisa");
$new_=$phone.$date1;

echo $phone."<br/>";
echo $desc_."<br/>";
echo $amt."<br/>";
//echo $pic."<br/>";
echo $day."<br/>";
echo $month."<br/>";
echo $year."<br/>";
echo $date."<br/>";



$servername = "localhost";
$username = "swiftexr";
$pass = "71113004";
$dbname = "swiftexr_mtiba";





// Create connection
$conn = new mysqli($servername, $username, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    //die("Connection failed: " . $conn->connect_error);
}

				
$sql = "INSERT INTO harambee VALUES ('".$phone."','".$desc_."','".$amt."','".$day."','". $month."','". $year."','". $date."','". $new_."')";
//$sql = "INSERT INTO test VALUES ('".$new_."')";
//

if ($conn->query($sql) === TRUE) {
    
    //upload pic
   //submit
   $target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "uploads/" . $new_)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
   //sumbit
//echo "New record created successfully";
?>
<div style="color: white; font-size: 2vw;">
    <center>
    Success. Click icon to view your profile.<br/>
<a style="color: white; font-size: 2vw;" href="mwananchi.php" title="Go To Mwananchi Profile"><img src="success.png" style="height: 40px; width: 40px;"/></a>
    </center>
</div>
<?php
} else {
//echo "Error: " . $sql . "<br>" . $conn->error;
?>
<div>
    <center>
    Error. Click icon to try again.<br/>
<a style="color: white; font-size: 2vw;" href="report.php" title="Go To Mwananchi Profile"><img src="error.png" style="height: 40px; width: 40px;"/></a>
    </center>
</div>
<?php
echo $new_;
          
}

?>
    </header>

</body>

</html>