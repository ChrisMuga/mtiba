<?php
session_start();
?>
<html>
    <head><title>Vigilant Citizen</title></head>
<body>
<?php
$id = $_POST["id_no"];
$pword = $_POST["password"];

echo $id_no."<br/>";
echo $password1."<br/>";

$servername = "localhost";
$username = "swiftexr";
$pass = "71113004";
$dbname = "swiftexr_mtiba";

 

// Create connection
$conn = new mysqli($servername, $username, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    //die("Connection failed: " . $conn->connect_error);
}

				


$sql = "SELECT * FROM members WHERE id_number=".$id;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $fname=$row["first_name"];
        $lname=$row["last_name"];
        $phone=$row["phone"];
        $location=$row["email"];
		$password_ = $row["password"];
	
    }
} else {
    echo "0 results";
        echo '<script type="text/javascript">'; 
echo 'window.location.href = "index.php";';
echo '</script>';
}
				
// Output "no suggestion" if no hint was found or output correct values
if ($pword==$password_)
{
	echo "1";
//	header("location: harambee.php");
	    echo '<script type="text/javascript">'; 
        echo 'window.location.href = "harambee.php";';
        echo '</script>';
}
$_SESSION["name"]=$fname." ".$lname;
$_SESSION["id"]=$id;
$_SESSION["location"]=$location;
$_SESSION["phone"]=$phone;


echo $fname." ".$lname." A-  ".$pword." B- ".$password_;
?> 
</body>
</html>