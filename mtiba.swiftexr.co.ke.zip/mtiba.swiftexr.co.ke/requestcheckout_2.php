<?php
error_reporting(E_ERROR | E_PARSE);
session_start();
?>
<html>
    <head>
        <title>MTIBA: Payment</title>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    </head>
    
    <body>
       <div class="container">
           <div class=row>
               <div class="col-md-12">
                   
               
<?php
$ENDPOINT = "https://safaricom.co.ke/mpesa_online/lnmo_checkout_server.php?wsdl";

$CALLBACK_URL = "processcheckout.php";
$CALL_BACK_METHOD = "POST";

$PAYBILL_NO = "898998";
$PRODUCT_ID = "1717171717171";

$MERCHENTS_ID = $PAYBILL_NO;

$MERCHANT_TRANSACTION_ID = generateRandomString();
$INFO = $PAYBILL_NO;
$TIMESTAMP = "20160510161908";//MUST BE THE ONE USED IN CREATING THE PASSWORD

//$TIMESTAMP = date("YmdHis",time());
//$PASSKEY = "your SAG password"
/*NB : PASSWORD MUST BE OBTAIN FROM THE BELOW FORMAT
 $PASSWORD = base64_encode(hash("sha256", $MERCHENTS_ID.$PASSKEY.$TIMESTAMP ,True));*/

$PASSWORD ='ZmRmZDYwYzIzZDQxZDc5ODYwMTIzYjUxNzNkZDMwMDRjNGRkZTY2ZDQ3ZTI0YjVjODc4ZTExNTNjMDA1YTcwNw==';

$AMOUNT = $_POST['amt'];
$NUMBER = $_POST['phone'];//format 254700000000
$NAME=$_POST['name'];
$id=$_SESSION['id'];
		//echo $id;
		//echo date("Y-m-d h:i:sa");

//echo $AMOUNT." ".$NUMBER." ".$NAME;

$body = '<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:tns="tns:ns" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/"><soapenv:Header><tns:CheckOutHeader><MERCHANT_ID>'.$PAYBILL_NO.'</MERCHANT_ID><PASSWORD>'.$PASSWORD.'</PASSWORD><TIMESTAMP>'.$TIMESTAMP.'</TIMESTAMP></tns:CheckOutHeader></soapenv:Header><soapenv:Body><tns:processCheckOutRequest><MERCHANT_TRANSACTION_ID>'.$MERCHANT_TRANSACTION_ID.'</MERCHANT_TRANSACTION_ID><REFERENCE_ID>'.$PRODUCT_ID.'</REFERENCE_ID><AMOUNT>'.$AMOUNT.'</AMOUNT><MSISDN>'.$NUMBER.'</MSISDN><ENC_PARAMS></ENC_PARAMS><CALL_BACK_URL>'.$CALLBACK_URL.'</CALL_BACK_URL><CALL_BACK_METHOD>'.$CALL_BACK_METHOD.'</CALL_BACK_METHOD><TIMESTAMP>'.$TIMESTAMP.'</TIMESTAMP></tns:processCheckOutRequest></soapenv:Body></soapenv:Envelope>'; /// Your SOAP XML needs to be in this variable

$servername = "localhost";
$username = "swiftexr";
$pass = "71113004";
$dbname = "swiftexr_mtiba";

// Create connection
$conn = new mysqli($servername, $username, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    //die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO contributions VALUES ('".$id."','".$AMOUNT."','".$NUMBER."','".date("Y-m-d h:i:sa")."')";

if ($conn->query($sql) === TRUE) {
    //echo "true";
    #yes
    try{
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_URL, $ENDPOINT); 
    curl_setopt($ch, CURLOPT_HEADER, 0); 

    curl_setopt($ch, CURLOPT_VERBOSE, '0');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body); 

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, '0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, '0');

    $output = curl_exec($ch);
    curl_close($ch);

// Check if any error occured
if(curl_errno($ch))
{
    echo 'Error no : '.curl_errno($ch).' Curl error: ' . curl_error($ch);
}
echo "<br/>";echo "<br/>";echo "<br/>";echo "<br/>";echo "<br/>";
print_r("<h2>Success. To complete this transaction, enter your Bonga PIN on your handset. if you don't have one dial *126*5# for instructions</h2>");
//echo $_SESSION['id']."<br/>";
echo "<a href='contributions.php?id=".$id."'><button class='btn btn-success'>OKAY</button></a>";

//now process the checkout;
include ('processcheckout.php');
processcheckout($MERCHANT_TRANSACTION_ID, $ENDPOINT,$PASSWORD,$TIMESTAMP);

echo "<script type='text/javascript'>swal('Success', 'Thank you. Please wait for MPESA Confirmation', 'success');</script>";
}

catch(Exception $ex){
echo $ex;
echo "<script type='text/javascript'>swal('Error!', 'Oops, Something went wront, try again', 'error');</script>";
}
    
} else {
//echo "Error: " . $sql . "<br>" . $conn->error;
echo "<script type='text/javascript'>swal('Error!', 'Oops, Something went wront, try again', 'error');</script>";
}

function generateRandomString() {
    $length = 10;
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>
</div>
           </div>
       </div> 
    </body>
</html>
