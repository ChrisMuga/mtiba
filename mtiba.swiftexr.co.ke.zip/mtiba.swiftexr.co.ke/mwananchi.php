<!DOCTYPE html>
    <?php
    session_start();
    ?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Vigilant Citizen: MWANANCHI</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top" style="color: white;">MWANANCHI PROFILE</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="index.php">Mwananchi</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="admin.php">Officer</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#portfolio">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

  
    <header style="text-align: left; color: black;">
        <br/><br/><br/>
        <div style="text-align: right; color: white;">
        <?php
        echo $_SESSION["name"]."<br/>";
        echo $_SESSION["location"]."<br/>";
        echo $_SESSION["id"]."<br/>";
        echo $_SESSION["phone"]."<br/>";
        ?>
        </div>
                   
                    <style>
                        table{
                            width: 100%;
                            border: none;
                            border-width: 0px;
                        }
                        
                        tr,td{
                                border-width: thin;
                                padding: 10px;
                                
                                opacity: 0.7;
                                color: green;
                                border-style: solid;
                                
                        }
                    </style>
                <center><div>
                      
                       
                              <table>
                               <tr><td>CRIME</td><td>CRIME DESCRIPTION</td><td>LOCATION</td><td>TIME OF INCIDENT</td><td>TIME OF REPORTING</td><td>WITNESS ID NO</td><td>WITNESS CONTACTS</td> <td>WITNESS NAME</td></tr>
                               <style>
                               .x{
                               	background-color: green;
                               }
                               .y{
                               	background-color: white;
                               }
                               </style>
                                <?php
$servername = "localhost";
$username = "root";
$pass = "root";
$dbname = "Crime_Reporting";

// Create connection
$conn = new mysqli($servername, $username, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    //die("Connection failed: " . $conn->connect_error);
}

				


$sql = "SELECT * FROM incidents where id_number=".$_SESSION["id"];
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    //init counter;
   	$x=1;
    while($row = $result->fetch_assoc()) {
    	if ($x%2==1)
    	{
    		$r_="x";
    	}else{
    		$r="y";
    	}

       echo"<tr class='".$r."'><td>".$row["crime"]."</td><td>"  . $row["crime_desc"]."</td><td>"  . $row["location"]. "</td><td>"  . $row["time_of_incident"]."</td><td>"  . $row["time_of_reporting"]."</td><td>"  . $row["id_number"]."</td><td>"  . $row["phone_number"]."</td><td>"  . $row["name"]. "</td></tr>";
        
	$x++;
    }
} else {
    echo "0 results";
}
				
?> 
                              </table>
                        
                        
     

                      </div></center>
                   
 </header>       
  

  

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>

</body>

</html>
