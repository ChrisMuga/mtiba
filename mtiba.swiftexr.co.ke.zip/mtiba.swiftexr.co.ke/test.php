<html>
    <head>
        <title>test</title>
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
       
    </head>
    <body>
    <form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
    <hr>
    <a href='contributions.php?id=070163514420170930073027am'>Contribute</a>
    <hr>
</form>
    </body>
    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
