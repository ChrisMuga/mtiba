<html>
    <head><title>Vigilant Citizen</title></head>
<body>
<?php
session_start();
$id = $_POST["id_no"];
$pword = $_POST["password"];

echo $id_no."<br/>";
echo $password1."<br/>";

$servername = "localhost";
$username = "root";
$pass = "root";
$dbname = "Crime_Reporting";

// Create connection
$conn = new mysqli($servername, $username, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    //die("Connection failed: " . $conn->connect_error);
}

				


$sql = "SELECT * FROM admin WHERE o_id=".$id;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $fname=$row["first_name"];
        $lname=$row["last_name"];
        $phone=$row["phone_number"];
        $location=$row["location"];
		$password_ = $row["password"];
        $station = $row["station"];
	
    }
} else {
    echo "0 results";
}
				
// Output "no suggestion" if no hint was found or output correct values
if ($pword==$password_)
{
	echo "1";
	header("location: view.php");
}
$_SESSION["name"]=$fname." ".$lname;
$_SESSION["id"]=$id;
$_SESSION["location"]=$location;
$_SESSION["phone"]=$phone;
$_SESSION["station"]=$station;


echo $fname." ".$lname." A-  ".$pword." B- ".$password_;
?> 
</body>
</html>